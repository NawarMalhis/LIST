/*
 * II.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: nmalhis
 */

#include "St_II.h"

namespace std {

St_II::St_II() {
	// TODO Auto-generated constructor stub
	ikey = 0;
	i2 = 0;
}

St_II::St_II(const St_II &ii) {
	ikey = ii.ikey;
	i2 = ii.i2;
}



St_II::~St_II() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */
